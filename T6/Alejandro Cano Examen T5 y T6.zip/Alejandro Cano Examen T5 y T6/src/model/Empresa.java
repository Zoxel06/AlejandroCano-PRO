package model;

import java.util.ArrayList;

public class Empresa {

    public Empresa(){

    }


}
