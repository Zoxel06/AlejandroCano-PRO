package database;

public interface SchemaDB {

    String DB_NAME = "pasajeros_ces";
    String TAB_CAR = "coches";
    String TAB_PASSENGER = "pasajeros_ces";
    String COL_ID = "id";
    String COL_REGISTRATION = "matricula";
    String COL_BRAND = "marca";
    String COL_MODEL = "modelo";
    String COL_COLOR = "color";
    String COL_PRICE = "precio";

}
