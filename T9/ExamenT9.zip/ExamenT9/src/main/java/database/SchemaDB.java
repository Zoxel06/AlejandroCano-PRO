package database;

public interface SchemaDB {

    String DB_NAME = "profesores_ces";
    String TAB_PRO = "profesores";
    String COL_NAME = "nombre";
    String COL_DNI = "dni";
    String COL_SALARY = "salario_total";

}
