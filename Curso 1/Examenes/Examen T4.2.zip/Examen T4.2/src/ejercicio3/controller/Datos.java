package ejercicio3.controller;

public class Datos {

    public String nombre;
    public String apellido;
    public int telefono;
    public String dni;
    public boolean disponibilidad;

}
