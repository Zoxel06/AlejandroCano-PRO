package ejercicio2.controller;

public class Calificacion {
}
